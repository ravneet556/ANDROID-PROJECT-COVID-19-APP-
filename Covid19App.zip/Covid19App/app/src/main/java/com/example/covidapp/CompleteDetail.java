package com.example.covidapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CompleteDetail extends AppCompatActivity {
    TextView titles,allc,activeCase,death,recovered;
    @Override
    protected void onCreate(Bundle savedInstancesState) {

        super.onCreate(savedInstancesState);
        setContentView(R.layout.complete_info);
        titles = findViewById(R.id.txtCountryName);
        allc = findViewById(R.id.txtallC);
        activeCase = findViewById(R.id.txtActiveC);
        death = findViewById(R.id.txtDeath);
        recovered= findViewById(R.id.txtRecovered);
      titles.setText(MainActivity.title);
      allc.setText(String.valueOf(MainActivity.allCases));
      activeCase.setText(String.valueOf(MainActivity.activeCases));
      death.setText(String.valueOf(MainActivity.deaths));
      recovered.setText(String.valueOf(MainActivity.Recovered));

    }
}
