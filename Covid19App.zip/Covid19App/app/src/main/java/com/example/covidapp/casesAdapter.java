package com.example.covidapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class casesAdapter extends BaseAdapter {
    private ArrayList<Cases> casedetails ;
   private  LayoutInflater layoutInflater;

    public casesAdapter(Context context,ArrayList<Cases> casedetails) {
        this.casedetails = casedetails;
        layoutInflater = LayoutInflater.from(context);

    }

    @Override
    public int getCount() {
        return casedetails.size();
    }

    @Override
    public Object getItem(int i) {
        return casedetails.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if(view==null){
            holder = new ViewHolder();
            view = layoutInflater.inflate(R.layout.list_details,null);
            holder.cntry=view.findViewById(R.id.txtcountry);
            holder.allcase=view.findViewById(R.id.txtAllCases);
            view.setTag(holder);
        }
        else
            holder = (ViewHolder) view.getTag();
        holder.cntry.setText(casedetails.get(i).getCountry());
        holder.allcase.setText(String.valueOf(casedetails.get(i).getAllCases()));

        return view;
    }
    static class ViewHolder{
        private  TextView cntry,allcase;
    }
}
